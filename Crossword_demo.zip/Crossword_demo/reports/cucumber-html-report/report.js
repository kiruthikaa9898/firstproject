$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/Feature/Crossword_demo.feature");
formatter.feature({
  "line": 2,
  "name": "Crossword website",
  "description": "",
  "id": "crossword-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Crossword_demo"
    }
  ]
});
formatter.scenario({
  "comments": [
    {
      "line": 4,
      "value": "#@TC_01_Crossword_demo"
    },
    {
      "line": 5,
      "value": "#"
    },
    {
      "line": 6,
      "value": "#@TC_01_crossword"
    },
    {
      "line": 7,
      "value": "#Scenario Outline: validate Login Functionality"
    },
    {
      "line": 8,
      "value": "#Given I launch the browser and enter the url"
    },
    {
      "line": 9,
      "value": "#When login page is opened"
    },
    {
      "line": 10,
      "value": "#Then I enter the \u003cusername\u003e and \u003cpassword\u003e"
    },
    {
      "line": 11,
      "value": "#And I click on the signin button"
    },
    {
      "line": 12,
      "value": "#"
    },
    {
      "line": 13,
      "value": "#Examples:"
    },
    {
      "line": 14,
      "value": "#|username                   \t| password         |"
    },
    {
      "line": 15,
      "value": "#|kiruthikaska@gmail.com\t    | Project          |"
    },
    {
      "line": 16,
      "value": "#"
    },
    {
      "line": 17,
      "value": "#"
    },
    {
      "line": 18,
      "value": "#@TC_02_Crossword_demo"
    },
    {
      "line": 19,
      "value": "#"
    },
    {
      "line": 20,
      "value": "#Scenario: wishlist"
    },
    {
      "line": 21,
      "value": "#Given launching the browser"
    },
    {
      "line": 22,
      "value": "#When wishlist page is opened"
    },
    {
      "line": 23,
      "value": "#Then continue shopping"
    },
    {
      "line": 24,
      "value": "#Then tell me available"
    }
  ],
  "line": 28,
  "name": "Logout",
  "description": "",
  "id": "crossword-website;logout",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 26,
      "name": "@TC_03_Crossword_demo"
    }
  ]
});
formatter.step({
  "line": 29,
  "name": "launched the browser",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "login is opened",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "logout the page",
  "keyword": "Then "
});
formatter.match({
  "location": "Logout_Page.launched_the_browser()"
});
formatter.result({
  "duration": 25818764600,
  "status": "passed"
});
formatter.match({
  "location": "Logout_Page.login_is_opened()"
});
formatter.result({
  "duration": 224244700,
  "error_message": "java.lang.NullPointerException\r\n\tat com.pages.LoginPage.login(LoginPage.java:21)\r\n\tat com.Stepdefinition.Logout_Page.login_is_opened(Logout_Page.java:48)\r\n\tat ✽.When login is opened(src/test/resources/Feature/Crossword_demo.feature:30)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "Logout_Page.logout_the_page()"
});
formatter.result({
  "status": "skipped"
});
});