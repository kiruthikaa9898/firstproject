package com.TestRunner;


import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions(
		features ="src/test/resources/Feature/Crossword_demo.feature",
				 
	    glue = {"com.Stepdefinition"},
		plugin = {"pretty", "html:reports/cucumber-html-report",
				"junit:target/cucumber-junit-report",
        "com.cucumber.listener.ExtentCucumberFormatter:target/Extentreports/Extentreport.html"},
				
		tags= {"@TC_01_Crossword_demo,@TC_02_Crossword_demo"},
		monochrome = true,
	
		strict = true
		)
public class Login_Runner {

}
