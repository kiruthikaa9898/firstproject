package com.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Library {

		public WebDriver driver=null;

		public void launch() {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Hari Work Station\\eclipse-workspace\\Crossword_demo\\src\\test\\resources\\Drivers\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get("https://www.crossword.in/");
		}

		public void quit() {
			driver.close();
		}
	public void launch1()
	{
		System.setProperty("WebDriver.firefox.driver","C:\\Users\\Hari Work Station\\eclipse-workspace\\Crossword_demo\\src\\test\\resources\\Drivers\\geckodriver.exe");
		 driver=new FirefoxDriver();
		driver.get("https://www.crossword.in/");
	}





	}

